using Unity.Collections;
using Unity.Mathematics;

namespace Shard
{
    internal struct Broadphase : System.IDisposable
    {
        public NativeList<int> BodyToProxy;
        public NativeList<Aabb> ProxyAabbs;

        public Broadphase(Allocator allocator)
        {
            BodyToProxy = new NativeList<int>(allocator);
            ProxyAabbs = new NativeList<Aabb>(allocator);
        }

        public void Dispose()
        {
            ProxyAabbs.Dispose();
            BodyToProxy.Dispose();
        }

        public void EnsureBodyCapacity(int bodyCount)
        {
            while (BodyToProxy.Length < bodyCount)
                BodyToProxy.Add(-1);

            while (ProxyAabbs.Length < bodyCount)
                ProxyAabbs.Add(default);
        }

        public int CreateProxy(BodyId bodyId, in Aabb worldAabb)
        {
            EnsureBodyCapacity(bodyId.Value + 1);
            int proxyId = bodyId.Value;
            BodyToProxy[bodyId.Value] = proxyId;
            ProxyAabbs[proxyId] = worldAabb;
            return proxyId;
        }

        public void UpdateProxy(int proxyId, in Aabb worldAabb)
        {
            ProxyAabbs[proxyId] = worldAabb;
        }

        public void RemoveProxy(int proxyId)
        {
            // leave AABB as-is; BodyToProxy mapping is cleared by caller
            _ = proxyId;
        }
    }

    internal struct Narrowphase : System.IDisposable
    {
        // Pair cache + manifolds
        public NativeList<ContactManifold> Manifolds;

        public Narrowphase(Allocator allocator)
        {
            Manifolds = new NativeList<ContactManifold>(allocator);
        }

        public void Dispose() => Manifolds.Dispose();
    }

    public struct ContactPoint
    {
        public float3 Position;
        public float Penetration;
        public uint FeatureId; // important for warm starting & mesh/voxel caching
    }

    public struct ContactManifold
    {
        public BodyId A;
        public BodyId B;
        public float3 Normal; // from A -> B
        public byte PointCount;
        public ContactPoint P0, P1, P2, P3;

        // Cached impulses per point for warm start (normal + friction)
        public float ImpulseN0, ImpulseN1, ImpulseN2, ImpulseN3;
        public float ImpulseT0, ImpulseT1, ImpulseT2, ImpulseT3;
    }

    internal struct ConstraintGraph : System.IDisposable
    {
        // Constraints as edges; built from joints + contacts.
        public NativeList<Constraint> Constraints;

        public ConstraintGraph(Allocator allocator)
        {
            Constraints = new NativeList<Constraint>(allocator);
        }

        public void Dispose() => Constraints.Dispose();
    }

    public enum ConstraintType : byte
    {
        Contact,
        Hinge,
        BallSocket,
        Prismatic,
        ConeTwist,
        Distance,
        Motor,
        Custom
    }

    public struct Constraint
    {
        public ConstraintType Type;
        public BodyId A;
        public BodyId B;
        public int PayloadIndex;   // points into per-type constraint payload pools
        public ushort Flags;
    }

    internal struct Solver : System.IDisposable
    {
        // Scratch + row buffers, impulses, etc. (per-world)
        public NativeList<SolverRow> Rows;

        public Solver(Allocator allocator)
        {
            Rows = new NativeList<SolverRow>(allocator);
        }

        public void Dispose() => Rows.Dispose();
    }

    /// Row-based solver core unit (Jacobian row / impulse clamp)
    public struct SolverRow
    {
        public BodyId A, B;

        public float3 JA_Linear;
        public float3 JA_Angular;
        public float3 JB_Linear;
        public float3 JB_Angular;

        public float EffectiveMass;
        public float Bias;
        public float Impulse;
        public float MinImpulse;
        public float MaxImpulse;
    }
}
